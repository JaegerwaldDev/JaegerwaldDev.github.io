﻿// Start your Cargo Trucker program here

string[] drawing = {
    "## #####    # ##",
    "## #####    # ##",
    "## #####    # ##",
    "## #####    # ##",
    "## #####    # ##",
    "## #####    # ##",
    "## ########## ##",
    "###          ###",
    "################",
    "################",
    "##            ##",
    "##            ##",
    "## ########## ##",
    "##            ##",
    " # ########## # ",
    "## ########## ##"
};

void Right()
{
    Left();
    Left();
    Left();
}
void TurnAround()
{
    Left();
    Left();
}
void Repeat(int amount, Action function)
{
    for (int i = 0; i < amount; i++)
    {
        function();
    }
}
void GoLeft()
{
    Left();
    Forward();
}
void GoRight()
{
    Right();
    Forward();
}
void Backward()
{
    TurnAround();
    Forward();
}

void Main()
{
    for (int i = 0; i<drawing.Length; i++)
    {
        if (drawing[i] == "")
        {
            for (int j = 0; j < 16; j++)
            {
                Repeat(17, PickUpBox);
                if (j != 15 & j != 16)
                {
                    Forward();
                }
            }
            TurnAround();
            Repeat(15, Forward);
            TurnAround();
            if (i != 15)
            {
                GoRight();
                Left();
            }
        } else
        {
            for (int j = 0; j < drawing[i].Length; j++)
            {
                if (drawing[i][j].ToString() != "#")
                {
                    Repeat(17, PickUpBox);
                }
                if (j != 15)
                {
                    Forward();
                }
            }
            TurnAround();
            Repeat(15, Forward);
            TurnAround();
            if (i != 15)
            {
                GoRight();
                Left();
            }
        }
    }
}
Main();